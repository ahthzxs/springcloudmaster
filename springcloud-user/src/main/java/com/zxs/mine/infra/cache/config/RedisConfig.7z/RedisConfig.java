package com.zxs.mine.infra.cache.config;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;

import java.lang.reflect.Method;

@Configuration
public class RedisConfig extends CachingConfigurerSupport {

    /*
     * 定義緩存數據 key 生成策略的bean 包名+類名+方法名+所有參數
     */
    @Bean
    public KeyGenerator wiselyKeyGenerator(){
        return new KeyGenerator() {
            @Override
            public Object generate(Object target, Method method, Object... params) {
                StringBuilder sb = new StringBuilder();
                sb.append(target.getClass().getName());
                sb.append(method.getName());
                for (Object obj : params) {
                    sb.append(obj.toString());
                }
                return sb.toString();
            }
        };

    }

    /*
     * 要啟用spring緩存支持,需創建一個 CacheManager的 bean，CacheManager 接口有很多實現，這裏Redis 的集成，用
     * RedisCacheManager這個實現類 Redis 不是應用的共享內存，它只是一個內存服務器，就像 MySql 似的，
     * 我們需要將應用連接到它並使用某種“語言”進行交互，因此我們還需要一個連接工廠以及一個 Spring 和 Redis 對話要用的
     * RedisTemplate， 這些都是 Redis 緩存所必需的配置，把它們都放在自定義的 CachingConfigurerSupport 中
     */
//    @Bean
//    public CacheManager cacheManager(@SuppressWarnings("rawtypes") RedisTemplate redisTemplate) {
//        RedisCacheManager cacheManager = new RedisCacheManager(redisTemplate);
//        // cacheManager.setDefaultExpiration(60);//設置緩存保留時間（seconds）
//        return cacheManager;
//    }


    @Bean
    public CacheManager cacheManager(RedisConnectionFactory connectionFactory) {
        return RedisCacheManager.create(connectionFactory);
    }


//    RedisCacheManager cm = RedisCacheManager.builder(connectionFactory)
//            .cacheDefaults(defaultCacheConfig())
//            .initialCacheConfigurations(singletonMap("predefined", defaultCacheConfig().disableCachingNullValues()))
//            .transactionAware()
//            .build();



    // 1.項目啟動時此方法先被註冊成bean被spring管理,如果沒有這個bean，則redis可視化工具中的中文內容（key或者value）都會以二進制存儲，不易檢查。
    @Bean
    public RedisTemplate<String, String> redisTemplate(RedisConnectionFactory factory) {
        StringRedisTemplate template = new StringRedisTemplate(factory);
        Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);
        ObjectMapper om = new ObjectMapper();
        om.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        jackson2JsonRedisSerializer.setObjectMapper(om);
        template.setValueSerializer(jackson2JsonRedisSerializer);
        template.afterPropertiesSet();
        return template;
    }
}